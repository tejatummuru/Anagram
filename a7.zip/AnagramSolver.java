/* CS 314 STUDENTS: FILL IN THIS HEADER AND THEN COPY AND PASTE IT TO YOUR
 * LetterInventory.java AND AnagramSolver.java CLASSES.
 *
 * Student information for assignment:
 *
 *  On my honor, <TEJA TUMMURU>, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID: tt26586
 *  email address: tt26586@utexas.edu
 *  TA name: hi Andrew :D
 *  Number of slip days I am using: 0
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AnagramSolver {
	
	//INSTANCE VARIABLE
	public Map<String, LetterInventory> storage; 
   
	//CONSTRUCTOR
    public AnagramSolver(Set<String> dictionary) {
    	storage = new HashMap<String, LetterInventory>();
    	for(Iterator<String> it = dictionary.iterator(); it.hasNext();) {
    		String result = it.next();
    		LetterInventory record = new LetterInventory(result);
    		storage.put(result, record);
    	}
    }

    public List<List<String>> getAnagrams(String s, int maxWords) {
    	//stores/initializes variables and calls the recursive method
    	char c = 0;    	
    	if((s.equals(null) && !('a' <= c && c <= 'z' && s.contains(c + ""))) || maxWords < 0) {
    		throw new IllegalArgumentException("preconditions not met");
    	}
    	LetterInventory mini = new LetterInventory(s);
    	int index = 0; //to virtually chrink the mini dictionary
    	ArrayList<String> found = new ArrayList<>();
    	ArrayList<String> eligible = miniDic(mini);
    	ArrayList<List<String>> result = new ArrayList<>();  	
    	recursiveCall(index, result, found, eligible, maxWords, mini, s);
    	Collections.sort(result, new AnagramComparator());
        return result;
    }
    
    private ArrayList<String> miniDic(LetterInventory mini){
    	//adds eligible words to a mini dictionary
    	ArrayList<String> eligible = new ArrayList<>();
    	for(Map.Entry<String, LetterInventory> entry: storage.entrySet()) {
    		//peruses the map and if the word is small enough and has 
    		//the right letters, it is added to a smaller arraylist of words    		
    		 if(mini.subtract(entry.getValue()) != null) {
    			 eligible.add(entry.getKey());
    		 }
    	}
    	return eligible;
    }
    
    public int recursiveCall(int index,  ArrayList<List<String>> result, ArrayList<String> found, ArrayList<String> eligible,
    		int maxWords, LetterInventory mini, String s) {
    	//BASE CASE
    	if(mini.size() == 0) {
    		ArrayList<String> temp = new ArrayList<>(found);
    		Collections.sort(temp);
    		result.add(temp);
       	}else {
       		//goes through every object in the array of eligible words and subtracts their invntories
       		//if the subtraction is ok, it adds it to the result and goes on if not it adds the inventory back
    		for(int i = index; i < eligible.size(); i++) {
                	LetterInventory temp2 = mini.subtract(storage.get(eligible.get(i)));
                	found.add(eligible.get(i));
        		if((found.size() <= maxWords || maxWords == 0) && !(temp2 == (null))) {
                	recursiveCall( i , result, found, eligible, maxWords, temp2, s);
        		}
        		//UNDO THE STEPS
            	found.remove(eligible.get(i));
        	}
    	}
    	return index;
    }
    
    private static class AnagramComparator implements Comparator<List<String>> {
    	//nested class for comparision
        public int compare(List<String> a1, List<String> a2) {
        	//sees of they are the same size
        	if(a1.size()!= a2.size()) {
        		return a1.size()-a2.size();
        	}else {
        		//if not it checks to see which word comes first lexicographically
        		int ind = 0;
        		while(a1.get(ind).equals(a2.get(ind)) && ind < a1.size()-1) {
        			ind++;
        		}
        		return a1.get(ind).compareTo(a2.get(ind));
        	}
        }
    } 
}