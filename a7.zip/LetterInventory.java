/* CS 314 STUDENTS: FILL IN THIS HEADER AND THEN COPY AND PASTE IT TO YOUR
 * LetterInventory.java AND AnagramSolver.java CLASSES.
 *
 * Student information for assignment:
 *
 *  On my honor, <TEJA TUMMURU>, this programming assignment is my own work
 *  and I have not provided this code to any other student.
 *
 *  UTEID: tt26586
 *  email address: tt26586@utexas.edu
 *  TA name: hi Andrew :D
 *  Number of slip days I am using: 0
 */
public class LetterInventory {
	
	//INSTANCE VARIABLES
	private String gram;
	public int [] storage;
	public static final int ALPHABET = 26;
	public static final int DIFFERENCE = 97;
	
	//CONSTUCTOR
	public LetterInventory(String word) { 
		if(word == null) {
			throw new IllegalStateException("String is null");
		}
		gram = word.toLowerCase();
		storage = new int[ALPHABET];
		alphabetStore();
	}

	//METHODS	
	public int get(char current) { 
		//gets the frequency of a certain character
		current = Character.toLowerCase(current);
		if(!('a' <= current && current <= 'z')) {
			throw new IllegalStateException("not an english character");
		}
		return storage[(int)current - DIFFERENCE];
	}
		
	public int size() { 
		//returns the size of the string/inventory left
		int count = 0;
		for(int i = 0; i < ALPHABET; i++) {
			if(storage[i] > 0) {
				count+=storage[i];
			}
		}
		return count;
	}

	
	public boolean isEmpty() {
		//returns whether the inventory is empty or not
		if(size() == 0) { 
			return true;
		}
		return false;
	}
	
	private int[] alphabetStore() {
		//private helper to add every character to the storage array
		for(int i = 0; i < gram.length(); i++) {
			char current = gram.charAt(i);
			if('a' <= current && current <= 'z') {
				int index = current - DIFFERENCE;
				storage[index]++;
			}
			
		}
		return storage;
	}

	public String toString() { 
		//converts the storage array by changing the respective index to a character and adding it to a string
		StringBuilder result = new StringBuilder();
		for(int i = 0; i < ALPHABET; i++) {
			if(storage[i]> 0 ) {
				for(int j = 0; j < storage[i]; j++) {
					result.append((char)(i + DIFFERENCE));
				}
			}
			
		}
		return result.toString();
	}

	public LetterInventory add(LetterInventory other) {
		//adds 2 inventories by addxing every index of the storage index
		if(other.equals(null)) {
			throw new IllegalStateException("the calling object is null");
		}
		LetterInventory result = new LetterInventory(this.gram + other.gram); //adds their strings
		for(int i = 0; i < ALPHABET; i++) {
			result.storage[i] = this.storage[i] + other.storage[i];
		}
		return result;
	}
	
	public LetterInventory subtract(LetterInventory other) { 
		//subtracts 2 inventories by subtracting every index of the storage array
		if(other.equals(null)) {
			throw new IllegalStateException("the calling object is null");
		}
		LetterInventory result = new LetterInventory("");
		for(int i = 0; i < ALPHABET; i++) {
			if(this.storage[i] - other.storage[i] < 0) {
				return null;
			}else {
				result.storage[i] = this.storage[i] - other.storage[i];
			}
		}
		return result;
	}
	
	public boolean equals(Object o) {
		//checks to see if 2 inventories are equal by checking the toStrings
		if (o instanceof LetterInventory) {
			if(this.toString().equals(o.toString())) {
				return true;
			}
		}
		return false;
	}
}
